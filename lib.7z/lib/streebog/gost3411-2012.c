/* 
 * Copyright (c) 2013, Alexey Degtyarev <alexey@renatasystems.org>. 
 * All rights reserved.
 *
 * GOST 34.11-2012 hash function with 512/256 bits digest.
 *
 * $Id$
 */

#include "gost3411-2012.h"
static void *
memalloc(const size_t size)
{
    void *p;

    /* Ensure p is on a 64-bit boundary. */
    if (posix_memalign(&p, (size_t)64, size))
        err(EX_OSERR, NULL);

    return p;
}

static void
reverse_order(unsigned char *in, size_t len)
{
    unsigned char c;
    unsigned int i, j;

    for (i = 0, j = (unsigned int)len - 1; i < j; i++, j--)
    {
        c = in[i];
        in[i] = in[j];
        in[j] = c;
    }
}

static void
convert_to_hex(unsigned char *in, unsigned char *out, size_t len,
               const unsigned int eflag)
{
    unsigned int i;
    char ch[3];

    if (len > 64)
        len = 64;

    memset(out, 0, 129);

    /* eflag is set when little-endian output requested */
    if (eflag)
        reverse_order(in, len);

    for (i = 0; i < len; i++)
    {
        sprintf(ch, "%02x", (unsigned char)in[i]);
        strncat((char *)&out[0], ch, 2);
    }
}


static void
shutdown(void)
{
    if (CTX != NULL)
        GOST34112012Cleanup(CTX);
}

unsigned char* compute_hash (char * string)
{
    atexit(shutdown);

    CTX = memalloc(sizeof(GOST34112012Context));

    unsigned char *buf __attribute__((aligned(16)));
    size_t size;

    GOST34112012Init(CTX, digest_size);

    size = strnlen((const char *)string, (size_t)4096);
    buf = memalloc(size);
    memcpy(buf, string, size);

    GOST34112012Update(CTX, buf, size);

    GOST34112012Final(CTX, &digest[0]);
    if (digest_size == 256)
        convert_to_hex(digest, hexdigest, 32, 0);
    else
        convert_to_hex(digest, hexdigest, 64, 0);

    return hexdigest;
}


int main(int argc, char *argv[]){
    if(argc == 2){
    unsigned char* a = compute_hash(argv[1]);
    printf("%s",a);
    }
    else
    {
        printf("Usage: ./hasher [string]");
        return 1;
    }
    return 0;
}
