GOST R 34.11-2012 hash function with 512/256 bit digest
=======================================================

[![Build Status](https://travis-ci.org/adegtyarev/streebog.svg?branch=master)](https://travis-ci.org/adegtyarev/streebog)

This is portable implementation of the GOST R 34.11-2012 hash function.
The standard for this hash function developed by the Center for
Information Protection and Special Communications of the Federal
Security Service of the Russian Federation with participation of the
Open joint-stock company "Information Technologies and Communication
Systems" (InfoTeCS JSC).

The standard published as [RFC 6986](https://tools.ietf.org/html/rfc6986).


Requirements
------------
* GCC, Clang or ICC compiler supporting 64-bit integers.

* GNU make (or any compatible make).


Compile and install
-------------------
The software is smart enough to detect the most suitable configuration
for running hardware and software platform.  In almost all cases it is
sufficient to run `make` on top of the source directory:

    # make
    gcc46 -g -O2 [other compile options..]

This will configure and compile a binary program file named
`gost3411-2012`.


Usage instructions
------------------
The program outputs GOST R 34.11-2012 hash digest in hexadecimal format.
Each file listed on the command line is processed and hash is printed
for each one.  Stdin is read as input when executed without arguments.

    # ./hasher [string]

Author
------
Alexey Degtyarev <alexey@renatasystems.org>
