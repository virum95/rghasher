#ifndef __GOST3411_LITTLE_ENDIAN__
#define __GOST3411_LITTLE_ENDIAN__
#endif
#ifndef __GOST3411_HAS_MMX__
#define __GOST3411_HAS_MMX__
#endif
#ifndef __GOST3411_HAS_SSE2__
#define __GOST3411_HAS_SSE2__
#endif
#ifndef __GOST3411_HAS_SSE41__
#define __GOST3411_HAS_SSE41__
#endif
