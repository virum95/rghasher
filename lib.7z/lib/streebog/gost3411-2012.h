/* 
 * Copyright (c) 2013, Alexey Degtyarev <alexey@renatasystems.org>. 
 * All rights reserved.
 *
 * GOST 34.11-2012 hash function with 512/256 bits digest.
 *
 * $Id$
 */

#include <err.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sysexits.h>
#include <unistd.h>

#include "gost3411-2012-core.h"

/* For benchmarking */
#include <sys/resource.h>
#include <sys/time.h>
#include <sys/types.h>

#define READ_BUFFER_SIZE 65536

#define TEST_BLOCK_LEN 8192

#ifdef __GOST3411_HAS_SSE2__
#define TEST_BLOCK_COUNT 50000
#else
#define TEST_BLOCK_COUNT 10000
#endif

#define DEFAULT_DIGEST_SIZE 512
#define ALGNAME "GOST R 34.11-2012"
#define VERSION "0.11"

GOST34112012Context *CTX;

unsigned char digest[64];
unsigned char hexdigest[129];
unsigned int digest_size = DEFAULT_DIGEST_SIZE;

const union uint512_u GOSTTestInput = {
#ifndef __GOST3411_BIG_ENDIAN__
    {0x3736353433323130ULL,
     0x3534333231303938ULL,
     0x3332313039383736ULL,
     0x3130393837363534ULL,
     0x3938373635343332ULL,
     0x3736353433323130ULL,
     0x3534333231303938ULL,
     0x0032313039383736ULL}
#else
    {0x3031323334353637ULL,
     0x3839303132333435ULL,
     0x3637383930313233ULL,
     0x3435363738393031ULL,
     0x3233343536373839ULL,
     0x3031323334353637ULL,
     0x3839303132333435ULL,
     0x3637383930313200ULL}
#endif
};


static void *
memalloc(const size_t size);

static void
reverse_order(unsigned char *in, size_t len);

static void
convert_to_hex(unsigned char *in, unsigned char *out, size_t len,
               const unsigned int eflag);


static void
shutdown(void);


unsigned char* compute_hash (char * string);


